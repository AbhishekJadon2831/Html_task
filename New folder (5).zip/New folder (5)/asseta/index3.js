document.getElementById("bar").addEventListener("click", () => {
    let heat2 = document.getElementById("heat2");
    if (heat2 .style.display == "none") {
        heat2 .style.display = "block"
    } else {
        heat2 .style.display = "none"
    }
})