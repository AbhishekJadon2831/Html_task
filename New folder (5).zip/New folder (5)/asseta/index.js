document.getElementById("bar").addEventListener("click", () => {
    let list = document.getElementById("nav-list");
    if (list.style.display == "none") {
        list.style.display = "block"
    } else {
        list.style.display = "none"
    }
})




document.getElementById("bar039").addEventListener("click", () => {
    let kp = document.getElementById("accordion");
    if (kp.style.display == "none") {
        kp.style.display = "block"
    } else {
        kp.style.display = "none"
    }
})

document.getElementById("bar03").addEventListener("click", () => {
    let kp = document.getElementById("accordion2");
    if (kp.style.display == "none") {
        kp.style.display = "block"
    } else {
        kp.style.display = "none"
    }
})

document.getElementById("bar0").addEventListener("click", () => {
    let kp = document.getElementById("accordion3");
    if (kp.style.display == "none") {
        kp.style.display = "block"
    } else {
        kp.style.display = "none"
    }
})

document.getElementById("bar019").addEventListener("click", () => {
    let kp = document.getElementById("accordion4");
    if (kp.style.display == "none") {
        kp.style.display = "block"
    } else {
        kp.style.display = "none"
    }
})

document.getElementById("bar010").addEventListener("click", () => {
    let kp = document.getElementById("accordion5");
    if (kp.style.display == "none") {
        kp.style.display = "block"
    } else {
        kp.style.display = "none"
    }
})


