document.getElementById("bar").addEventListener("click", () => {
    let main2 = document.getElementById("main2");
    if (main2.style.display == "none") {
        main2.style.display = "block"
    } else {
        main2.style.display = "none"
    }
})

